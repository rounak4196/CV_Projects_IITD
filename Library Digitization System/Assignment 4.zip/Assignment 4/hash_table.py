from prime_generator import get_next_size

class HashTable:
    def __init__(self, collision_type, params):

        self.params = params
        self.collision_type = collision_type
        if collision_type == "Chain" or collision_type == "Linear":
            self.z = params[0]
            self.table_size = params[1]

        if collision_type == "Double":
            self.z = params[0]
            self.z2 = params[1]
            self.c2 = params[2]
            self.table_size = params[3]
        if collision_type == "Chain":
            
            self.table = [[] for _ in range(self.table_size)]
        else:
            self.table=[None]*self.table_size

        self.count = 0
        
        

    def insert(self, x):
        slot = self.hash_primary(x)
        if self.collision_type == "Chain":
            if self.table[slot] is None:
                self.table[slot] = []
            
                

            if x not in self.table[slot]:
                self.table[slot].append(x)
                self.count += 1 

        elif self.collision_type == "Linear":
            if self.count >= self.table_size:
                    raise Exception
            while self.table[slot] is not None and self.table[slot] != x:
                slot = (slot + 1) % self.table_size

            if self.table[slot] is None:
                self.table[slot] = x    
                self.count+=1
        elif self.collision_type == "Double":
            if self.count >= self.table_size:
                    raise Exception
            initial_value = slot
            step = self.hash_secondary(x)
            while self.table[slot] is not None and self.table[slot] != x:
                slot = (slot + step) % self.table_size
                if slot == initial_value:
                    raise Exception
            if self.table[slot] is None:
                self.table[slot] = x    
                self.count+=1

    def find(self, key):
        slot = self.hash_primary(key)
        if self.collision_type == "Chain":
            
            return key in self.table[slot]
        
        elif self.collision_type == "Linear":
            initial_slot = slot 
            while self.table[slot] is not None:
                if self.table[slot] == key:
                    return True
                slot = (slot + 1) % self.table_size
                if slot == initial_slot:
                    return False
            return False
        
        elif self.collision_type == "Double":
            initial_slot = slot 
            step = self.hash_secondary(key)
            while self.table[slot] is not None:
                if self.table[slot] == key:
                    return True
                slot = (slot + step) % self.table_size
                if slot == initial_slot:
                    return False
            return False


    def get_slot(self, key):
        initial_slot = self.hash_primary(key) 

        return initial_slot
        
        
        

    def get_load(self):
        
        return self.count / self.table_size if self.table_size > 0 else 0






    def rehash(self):
        pass

    

            
   
    def hash_primary(self, key):
        if isinstance(key, tuple):
            key = key[0]
        hash_value = 0
        p_pow = 1
        for char in key:
          
            if 'a' <= char <= 'z':
                char_value = ord(char) - ord('a')
            elif 'A' <= char <= 'Z':
                char_value = ord(char) - ord('A') + 26
            else:
                char_value = 0  # Default for non-alphabet characters

            hash_value = (hash_value + char_value * p_pow) % self.table_size
            p_pow = (p_pow * self.z) % self.table_size

        return hash_value

    def hash_secondary(self, key):
        if isinstance(key, tuple):
            key = key[0]
        hash_value = 0
        p_pow = 1
        for char in key:
           
            if 'a' <= char <= 'z':
                char_value = ord(char) - ord('a')
            elif 'A' <= char <= 'Z':
                char_value = ord(char) - ord('A') + 26
            else:
                char_value = 0  

            hash_value = (hash_value + char_value * p_pow) % self.c2
            p_pow = (p_pow * self.z2) % self.c2

        return self.c2 - (hash_value % self.c2)


    def __str__(self):
        if self.collision_type == "Chain":
            result = []
            for slot in self.table:
                if not slot:
                    result.append("<EMPTY>")
                else:
                    result.append(" ; ".join(str(x) for x in slot))
            return " | ".join(result)
        else:
            result = []
            for entry in self.table:
                if entry is None:
                    result.append("<EMPTY>")
                else:
                    result.append(str(entry))
            return " | ".join(result)



class HashSet(HashTable):
    def __init__(self, collision_type, params):
        super().__init__(collision_type, params)

    def insert(self, key):
        
        super().insert(key)

    def find(self, key):
        return super().find(key)

    def get_slot(self, key):
        return super().get_slot(key)

    def get_load(self):
        return super().get_load()

    def __str__(self):
        return super().__str__()


class HashMap(HashTable):
    def __init__(self, collision_type, params):
        super().__init__(collision_type, params)

    def insert(self, x):
        key, value = x
        slot = self.hash_primary(key)

        # Handling Chain collision resolution
        if self.collision_type == "Chain":
            if self.table[slot] is None:
                self.table[slot] = []
            
           
            found = False
            for item in self.table[slot]:
                if item[0] == key:
                    # Key is found
                    found = True
                    break
            if not found:
                 
                
                self.table[slot].append((key, value))
                self.count += 1

       
        elif self.collision_type == "Linear":
            if self.count >= self.table_size:
                raise Exception("Hash table is full")       
            initial_slot = slot
            while self.table[slot] is not None:
                existing_key, _ = self.table[slot]
                if existing_key == key:
                   
                    return
                
                slot = (slot + 1) % self.table_size
                if slot == initial_slot:
                
                    raise Exception
           
            self.table[slot] = (key, value)
            self.count += 1

        
        elif self.collision_type == "Double":
            if self.count >= self.table_size:
                raise Exception("Hash table is full")    
            initial_slot = slot
            step = self.hash_secondary(key)
            while self.table[slot] is not None:
                existing_key, _ = self.table[slot]
                if existing_key == key:
                    
                    return
               
                slot = (slot + step) % self.table_size
                if slot == initial_slot:
                  
                    raise Exception("Hash table is full")
          
            self.table[slot] = (key, value)
            self.count += 1

    def find(self, key):
        slot = self.hash_primary(key)
        
     
        if self.collision_type == "Chain":
            if self.table[slot] is None:
                self.table[slot] = []

            
            for existing_key, value in self.table[slot]:
                if existing_key == key:
                    return value 
            return None 
        
        elif self.collision_type == "Linear":
            initial_slot = slot
            while self.table[slot] is not None:
                if self.table[slot][0] == key:
                    return self.table[slot][1]
                slot = (slot + 1) % self.table_size
                if slot == initial_slot:
                    break
            return None
            
        elif self.collision_type == "Double":
            initial_slot = slot
            step = self.hash_secondary(key)
            while self.table[slot] is not None:
                if self.table[slot][0] == key:
                    return self.table[slot][1]
                slot = (slot + step) % self.table_size
                if slot == initial_slot:
                    break
            return None

    


    def get_slot(self, key):
        return super().get_slot(key)

    def get_load(self):
        return super().get_load()

    def _str_(self):
        if self.collision_type == "Chain":
            result = []
            for slot in self.table:
                if not slot:
                    result.append("<EMPTY>")
                else:
                    result.append(" ; ".join(f"({k}, {v})" for k, v in slot))
            return " | ".join(result)
        else:
            result = []
            for entry in self.table:
                if entry is None:
                    result.append("<EMPTY>")
                else:
                    k, v = entry
                    result.append(f"({k}, {v})")
            return " | ".join(result)
        
