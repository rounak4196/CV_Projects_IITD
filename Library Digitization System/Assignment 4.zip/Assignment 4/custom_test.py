import random
import string
from dynamic_hash_table import DynamicHashSet, DynamicHashMap
from prime_generator import get_next_size

def random_string(length=5):
    """Generate a random string of fixed length."""
    letters = string.ascii_letters  # Allows both lowercase and uppercase
    return ''.join(random.choice(letters) for i in range(length))

def test_dynamic_hashset():
    print("Testing DynamicHashSet...\n")
    # Initialize with a small table size to trigger rehashing quickly
    collision_type = random.choice(["Chain", "Linear", "Double"])
    hashset = DynamicHashSet(collision_type, params=[5, 31, 7, 17] if collision_type == "Double" else [5, 31])

    elements = set()
    for _ in range(20):  # Insert 20 random elements
        key = random_string()
        print(f"Inserting key '{key}'")
        hashset.insert(key)
        elements.add(key)
        print(hashset)  # Print hash table after each insertion
        assert key in elements, "Inserted key not found in the set."

    # Test search operations
    print("\nTesting search in DynamicHashSet...\n")
    for key in elements:
        assert hashset.find(key), f"Key '{key}' should be present but is not found."
    missing_key = random_string()
    assert not hashset.find(missing_key), f"Key '{missing_key}' should not be present but was found."

    print("DynamicHashSet tests passed!\n")

def test_dynamic_hashmap():
    print("Testing DynamicHashMap...\n")
    # Initialize with a small table size to trigger rehashing quickly
    collision_type = random.choice(["Chain", "Linear", "Double"])
    hashmap = DynamicHashMap(collision_type, params=[5, 31, 7, 17] if collision_type == "Double" else [5, 31])

    key_value_pairs = {}
    for _ in range(20):  # Insert 20 random (key, value) pairs
        key = random_string()
        value = random.randint(100, 200)
        print(f"Inserting key-value pair ('{key}', {value})")
        hashmap.insert((key, value))
        key_value_pairs[key] = value
        print(hashmap)  # Print hash table after each insertion
        assert key in key_value_pairs, "Inserted key not found in the map."

    # Test search operations
    print("\nTesting search in DynamicHashMap...\n")
    for key, value in key_value_pairs.items():
        assert hashmap.find(key), f"Key '{key}' should be present but is not found."
        found_value = hashmap.find(key)
        assert found_value == value, f"Expected value {value} for key '{key}', found {found_value}."

    missing_key = random_string()
    assert not hashmap.find(missing_key), f"Key '{missing_key}' should not be present but was found."

    print("DynamicHashMap tests passed!\n")

if __name__ == "__main__":
    test_dynamic_hashset()
    test_dynamic_hashmap()
