#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

void solve() {
    int n;
    cin >> n;
    vector<ll> arr(n);

    for (int i = 0; i < n; ++i) {
        cin >> arr[i];
    }
    
    if(n == 1){
        cout << 1 << endl ;
        
    }

    else if (n % 2 == 0) {
        // For even-sized array, calculate the maximum difference
        ll max_diff = 0;
        for (int i = 0; i < n - 1; i += 2) {
            max_diff = max(max_diff, abs(arr[i] - arr[i + 1]));
        }
        cout << max_diff << endl;
    } else {
        // For odd-sized array, calculate minimum of maximum differences by skipping one even index
        ll min_of_max_diffs = LLONG_MAX;

        for (int skip = 0; skip < n; skip += 2) {
            ll max_diff_in_config = 0;
            
            for (int i = 0; i < n-1;) {
                if (i == skip || i + 1 == skip) {
                   i=i+1 ;
                    continue; // Skip the selected even index
                }
                max_diff_in_config = max(max_diff_in_config, abs(arr[i] - arr[i + 1]));
                i +=2 ;
            }

            // Update minimum of the maximum differences
            min_of_max_diffs = min(min_of_max_diffs, max_diff_in_config);
        }
        
        cout << min_of_max_diffs << endl;
    }
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);

    int t;
    cin >> t; // Read number of test cases

    while (t--) {
        solve(); // Solve each test case
    }

    return 0;
}
