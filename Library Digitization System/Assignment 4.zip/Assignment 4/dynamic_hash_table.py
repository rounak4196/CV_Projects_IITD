from hash_table import HashSet, HashMap
from prime_generator import get_next_size

class DynamicHashSet(HashSet):
    def __init__(self, collision_type, params):
        super().__init__(collision_type, params)
        
    def rehash(self):
        # Get the next prime table size
        new_table_size = get_next_size()
        
        
        old_table = self.table
        self.table = [None] * new_table_size
        self.table_size = new_table_size
        self.count = 0
        
       
        for item in old_table:
            if item:
                if self.collision_type == "Chain":
                    
                    for key in item:
                        self.insert(key)
                else:
                   
                    self.insert(item)

        
    def insert(self, x):
        # YOU DO NOT NEED TO MODIFY THIS
        super().insert(x)
        
        if self.get_load() >= 0.5:
            self.rehash()
            
            
class DynamicHashMap(HashMap):
    def __init__(self, collision_type, params):
        super().__init__(collision_type, params)
        
    def rehash(self):
        
        new_table_size = get_next_size()
        
        
        old_table = self.table
        self.table = [None] * new_table_size
        self.table_size = new_table_size
        self.count = 0
        
        
        for x in old_table:
            if x is not None:
                if self.collision_type == "Chain":
                    for (key, value) in x:
                        self.insert((key, value))
                elif x is not None:
                    self.insert(x)
        
        pass
        
    def insert(self, key):
        # YOU DO NOT NEED TO MODIFY THIS
        super().insert(key)
        
        if self.get_load() >= 0.5:
            self.rehash()


