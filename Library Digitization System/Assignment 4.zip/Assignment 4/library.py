import hash_table as ht

class DigitalLibrary:
    # DO NOT CHANGE FUNCTIONS IN THIS BASE CLASS
    def __init__(self):
        pass
    
    def distinct_words(self, book_title):
        pass
    
    def count_distinct_words(self, book_title):
        pass
    
    def search_keyword(self, keyword):
        pass
    
    def print_books(self):
        pass
    
class MuskLibrary(DigitalLibrary):
    # musk merge sort
    def merge_sort(self, arr, parameter):
       
        def merge(left, right, parameter):
            mergedans = []
            i = j = 0

            while i < len(left) and j < len(right):
                if left[i] < right[j]:
                    if parameter == 0 and (not mergedans or mergedans[-1] != left[i]):
                        mergedans.append(left[i])
                    elif parameter == 1:
                        mergedans.append(left[i])
                    i += 1
                elif left[i] > right[j]:
                    if parameter == 0 and (not mergedans or mergedans[-1] != right[j]):
                        mergedans.append(right[j])
                    elif parameter == 1:
                        mergedans.append(right[j])
                    j += 1
                else:
                    if parameter == 0 and (not mergedans or mergedans[-1] != left[i]):
                        mergedans.append(left[i])
                    elif parameter == 1:
                        mergedans.append(left[i])
                    i += 1
                    j += 1

            while i < len(left):
                if parameter == 0 and (not mergedans or mergedans[-1] != left[i]):
                    mergedans.append(left[i])
                elif parameter == 1:
                    mergedans.append(left[i])
                i += 1
            while j < len(right):
                if parameter == 0 and (not mergedans or mergedans[-1] != right[j]):
                    mergedans.append(right[j])
                elif parameter == 1:
                    mergedans.append(right[j])
                j += 1

            return mergedans

        def merge_sort_withparameter(arr, parameter):
            if len(arr) < 2:
                return arr
            mid = len(arr) // 2
            left = merge_sort_withparameter(arr[:mid], parameter)
            right = merge_sort_withparameter(arr[mid:], parameter)

            return merge(left, right, parameter)

        return merge_sort_withparameter(arr, parameter)

    def merge_sort_new(self, arr):
        def merge_new(left, right):
            merged = []
            i = j = 0

            while i < len(left) and j < len(right):
                if left[i][0] < right[j][0]:
                    merged.append(left[i])
                    i += 1
                else:
                    merged.append(right[j])
                    j += 1

            while i < len(left):
                merged.append(left[i])
                i += 1
            while j < len(right):
                merged.append(right[j])
                j += 1

            return merged

        def merge_sort_simple(arr):
            if len(arr) < 2:
                return arr
            mid = len(arr) // 2
            left = merge_sort_simple(arr[:mid])
            right = merge_sort_simple(arr[mid:])

            return merge_new(left, right)

        return merge_sort_simple(arr)

    def __init__(self, book_titles, texts):
        self.library = []
        for i in range(len(book_titles)):
            sorted_word = self.merge_sort(texts[i], 0)
            self.library.append((book_titles[i], sorted_word))
        self.library = self.merge_sort_new(self.library)

    
    def distinct_words(self, book_title):
        index = self.binary_search(self.library, book_title)    
        ans=[]
        given_book_tuple = self.library[index]
        for word in given_book_tuple[1]:
          
            ans.append(word)


        return ans

        
    
    def count_distinct_words(self, book_title):
        index = self.binary_search(self.library, book_title)
        given_book_tuple = self.library[index]
        ans = 0
        for word in given_book_tuple[1]:
            ans += 1
        return ans



    
    
    def search_keyword(self, keyword):
        ans = []
        for book in self.library:
            
            if self.binary_search_keyword(book[1], keyword) != -1:
                ans.append(book[0])
        return ans
    
    def print_books(self):
       
    
        for booktitle, bookwords in self.library:
            print(f"{booktitle}: {' | '.join(bookwords)}")
       
    def binary_search_keyword(self, arr, target):
        left, right = 0, len(arr) - 1

        while left <= right:
            mid = (left + right) // 2
            if arr[mid] == target:
                return mid
            elif arr[mid] < target:
                left = mid + 1
            else:
                right = mid - 1
        return -1 

    def binary_search(self , arr, target):
        left, right = 0, len(arr) - 1

        while left <= right:
            mid = (left + right) // 2
            
            if arr[mid][0] == target:
                return mid
            elif arr[mid][0] < target:
                left = mid + 1
            else:
                right = mid - 1

        return -1  


class JGBLibrary(DigitalLibrary):
    # IMPLEMENT ALL FUNCTIONS HERE
    def __init__(self, name, params):
        '''
        name    : "Jobs", "Gates" or "Bezos"
        params  : Parameters needed for the Hash Table:
            z is the parameter for polynomial accumulation hash
            Use (mod table_size) for compression function
            
            Jobs    -> (z, initial_table_size)
            Gates   -> (z, initial_table_size)
            Bezos   -> (z1, z2, c2, initial_table_size)
                z1 for first hash function
                z2 for second hash function (step size)
                Compression function for second hash: mod c2
        '''
        
        self.name=name
        if name=="Jobs" or name=="Gates":
            if name=="Jobs":
                collision_type="Chain"
            elif name=="Gates":
                collision_type="Linear"
            z,table_size=params
            hash_parameter=(z,table_size)
        # elif name=="Gates":
        #     collision_type="Linear"
        #     z,table_size=params
        #     hash_parameter=(z,table_size)
        elif name=="Bezos":
            collision_type="Double"
            z1,z2,c2,table_size=params
            hash_parameter=(z1,z2,c2,table_size)

        self.book_hashmap=ht.HashMap(collision_type,hash_parameter)
        self.list_book=[]          


        pass
    
    def add_book(self, book_title, text):
        self.list_book.append(book_title)
        book_hashset=ht.HashSet(self.book_hashmap.collision_type,self.book_hashmap.params)
        for word_to_add in text:
            if  book_hashset.find(word_to_add) is not True:
                book_hashset.insert(word_to_add)
        x=(book_title,book_hashset)
        self.book_hashmap.insert(x)
        

    
    def distinct_words(self, book_title):
        book_to_check=self.book_hashmap.find(book_title)
        aet=[]
        if book_to_check is  not None :
            for item in book_to_check.table:
                if book_to_check.collision_type == "Chain" :
                    for index in item:
                        aet.append(index) 
                    

                elif book_to_check.collision_type == "Linear"   :
                    if item is not None: 
                        aet.append(item)
                elif book_to_check.collision_type == "Double":
                    if item is not None: 
                        aet.append(item)

        return aet
        
    
    def count_distinct_words(self, book_title):
        return self.book_hashmap.find(book_title).count
        
        
    
    def search_keyword(self, keyword):
        ans=[]
        for book in self.list_book :
            book_ka_hash=self.book_hashmap.find(book)
            if book_ka_hash is not None :
                if book_ka_hash.find(keyword):
                    ans.append(book)
        return ans

    
    def print_books(self):
        ans = []
        for i in range(len(self.book_hashmap.table)):  
            
            if self.name == 'Jobs' and self.book_hashmap.table[i] is not None:
                for item in self.book_hashmap.table[i]:
                    ans.append(item)
            elif self.name == 'Gates' and self.book_hashmap.table[i] is not None:
                ans.append(self.book_hashmap.table[i])
            elif self.name == 'Bezos' and self.book_hashmap.table[i] is not None:
                ans.append(self.book_hashmap.table[i])
        for x in ans:
            print(x[0] + ":", x[1])