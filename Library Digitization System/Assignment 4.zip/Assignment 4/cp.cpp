#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

void solve() {
    ll n;
    cin >> n;
    vector<ll> a(n);
    
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }
    
    // Step 1: Extract unique elements and sort
    set<ll> unique_elements(a.begin(), a.end());
    vector<ll> unique_a(unique_elements.begin(), unique_elements.end());
    
    // Step 2: Find the median of unique elements
    ll median = unique_a[unique_a.size() / 2]; // Middle element for odd or lower middle for even size
    
    // Sort the original array 'a' to apply transformations based on the found median
    int median_index=0;
    sort(a.begin(), a.end());
    for(int i=0;i<n;i++){
        if(a[i]==median){
            i=median_index;
            break;

        }
    }
    
    int ans = 0;
    
    // Modify the first half of the array to satisfy the triangle inequality
    for (int i = 0; i < median_index; i++) {
        if (a[i] + a[i + 1] <= median) {  // If condition fails, modify
            ans++;
            a[i] = median;  // Set the element to the median value
        }
    }
    
    int k = 1;
    sort(a.begin(),a.end());
    int mini = a[0] + a[1];
    
    // Check the second half for triangle inequality and modify if necessary
    for (int i = median_index+ 1; i < n; i++) {
        if (a[i] >= mini) {  // If the condition fails
            ans++;
            mini = a[0 + k] + a[1 + k];  // Update mini based on updated elements
            k++;
        }
    }
    
    cout << ans << endl;  // Output the number of modifications needed
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);

    int t;
    cin >> t;  // Read the number of test cases

    while (t--) {
        solve();  // Solve each test case
    }
  
    return 0;
}
